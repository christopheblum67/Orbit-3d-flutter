package com.orbit3d.tv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
