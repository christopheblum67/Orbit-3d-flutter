﻿# 🪐 ORBIT 3D

**Application IPTV avec visualisation 3D - Flutter + Rust FFI**

> **VERSION:** 1.0.0 | **Status:** ✅ Corrigé & Prêt à compiler
> 
> https://github.com/christopheblum67/orbit-3d

## ✨ Quoi de Neuf (v1.0 - CORRECTIONS APPLIQUÉES)

### 🔧 Correctifs Gradle & Build
- ✅ Migré `allprojects` → `dependencyResolutionManagement` (Gradle 8.x)
- ✅ Intégration CMake pour compilation C++ native
- ✅ Support complet des architectures ARM (arm64-v8a, armeabi-v7a)
- ✅ Configuration moderne settings.gradle avec error handling

### 🏗️ Correctifs Natifs
- ✅ Renommé `cargo.toml` → `Cargo.toml` (Rust conform)
- ✅ Implémenté CMakeLists.txt complet pour ambilight C++
- ✅ JNI Libraries correctement configurées

### 📱 Correctifs Android
- ✅ AndroidManifest.xml: FQN MainActivity, permissions IPTV
- ✅ Network Security Config: autorisation HTTP/streams
- ✅ Support Android TV (Leanback launcher)
- ✅ Hardware acceleration activée

### 📝 Fichiers Nouveaux/Corrigés
- ✅ `android/local.properties` (template - À ADAPTER!)
- ✅ `build.sh` amélioré avec checks et validations
- ✅ Documentation complète des corrections

---

## 🚀 Quick Start

### Prérequis
```bash
✅ Flutter SDK (3.0+)
✅ Android SDK (API 34)
✅ Rust + cargo-ndk
✅ Git
```

### Compilation
```bash
# 1. Adapter les chemins SDK
nano android/local.properties
# → flutter.sdk=/ton/chemin/flutter
# → sdk.dir=/ton/chemin/android/sdk

# 2. Build APK
bash build.sh

# ✅ APK générée: build/app/outputs/flutter-apk/app-release.apk
```

---

## 📋 Mode Test Panels
* Pro : TEST-PANEL-PRO-2026
* Free : TEST-PANEL-FREE-2026

---

## 📚 Documentation
- 📖 [README_ORBIT_CORRECTIONS.md](README_ORBIT_CORRECTIONS.md) - Détail des 9 corrections
- 📖 [ARCHITECTURE.md](ARCHITECTURE.md) - Tech Stack

---

## 🛠️ Structure du Projet

```
orbit-3d/
├── lib/                           # Code Dart/Flutter
│   ├── main.dart                 # Entry point
│   ├── player/                   # Lecteur vidéo
│   ├── services/                 # Services EPG/Cloud
│   └── database/                 # Drift database
│
├── android/                       # Code natif Android
│   ├── app/
│   │   ├── build.gradle         # ✅ FIXÉ
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml  # ✅ FIXÉ
│   │   │   ├── cpp/CMakeLists.txt   # ✅ FIXÉ
│   │   │   ├── kotlin/MainActivity  # OK
│   │   │   └── res/xml/
│   │   │       └── network_security_config.xml  # ✅ FIXÉ
│   │   └── src/main/jniLibs/     # Compiled Rust libs
│   │
│   ├── build.gradle              # ✅ FIXÉ
│   ├── settings.gradle           # ✅ FIXÉ
│   ├── local.properties          # ✅ NOUVEAU (A adapter!)
│   └── gradle.properties         # OK
│
├── native/                        # Code Rust (FFI)
│   ├── Cargo.toml                # ✅ RENOMMÉ (cargo.toml → Cargo.toml)
│   └── src/lib.rs                # Rust interop
│
├── build.sh                       # ✅ FIXÉ (Build script)
├── pubspec.yaml                  # Flutter dependencies
└── README_ORBIT_CORRECTIONS.md    # 📖 Détail des fixes
```

---

## ✅ Status Build

| Component | Status | Notes |
|-----------|--------|-------|
| Gradle | ✅ FIXÉ | dependencyResolutionManagement |
| Rust FFI | ✅ FIXÉ | Cargo.toml casing |
| CMake | ✅ FIXÉ | Compilation C++ natives |
| Manifests | ✅ FIXÉ | FQN + network config |
| APK Build | ✅ READY | bash build.sh |

---

## 🐛 Problèmes Résolus

### Before (❌ Cassé):
- cargo.toml (minuscule) → Rust crash
- allprojects format → Gradle deprecation warning
- CMakeLists.txt vide → C++ non compilé
- Manifests incomplets → Runtime errors
- network_security_config vide → HTTP bloqué

### After (✅ Fixé):
- Cargo.toml majuscule → ✅ Rust OK
- dependencyResolutionManagement → ✅ Gradle 8.x compatible
- CMakeLists.txt implémenté → ✅ C++ compilation OK
- Manifests complets → ✅ Runtime OK
- network_security_config configuré → ✅ IPTV streams OK

---

## 📞 Support

**Besoin d'aide?** Voir [README_ORBIT_CORRECTIONS.md](README_ORBIT_CORRECTIONS.md)

---

**Créé avec ❤️ par la Task Force ORBIT-3D**

v1.0-CORRECTED | August 2026

