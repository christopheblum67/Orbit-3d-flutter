use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug)]
pub struct Channel {
    pub id: String,
    pub name: String,
    pub stream_url: String,
    pub logo: String,
    pub group: String,
}

#[no_mangle]
pub extern "C" fn parse_m3u_native(input: *const c_char) -> *mut c_char {
    if input.is_null() {
        return CString::new("[]").unwrap().into_raw();
    }

    let c_str = unsafe { CStr::from_ptr(input) };
    let str_slice = match c_str.to_str() {
        Ok(s) => s,
        Err(_) => return CString::new("[]").unwrap().into_raw(),
    };

    let mut channels: Vec<Channel> = Vec::new();
    let mut current_name = String::new();
    let mut current_logo = String::new();
    let mut current_group = String::new();
    let mut current_id = String::new();

    for line in str_slice.lines() {
        let line = line.trim();
        if line.starts_with("#EXTINF:") {
            current_id = extract_attr(line, "tvg-id").unwrap_or_else(|| format!("ch_{}", channels.len()));
            current_logo = extract_attr(line, "tvg-logo").unwrap_or_default();
            current_group = extract_attr(line, "group-title").unwrap_or_else(|| "Général".to_string());

            if let Some(pos) = line.rfind(',') {
                current_name = line[pos + 1..].trim().to_string();
            } else {
                current_name = "Chaîne sans nom".to_string();
            }
        } else if !line.starts_with('#') && !line.is_empty() {
            channels.push(Channel {
                id: current_id.clone(),
                name: current_name.clone(),
                stream_url: line.to_string(),
                logo: current_logo.clone(),
                group: current_group.clone(),
            });
            current_name.clear();
            current_logo.clear();
            current_group.clear();
            current_id.clear();
        }
    }

    let json_res = serde_json::to_string(&channels).unwrap_or_else(|_| "[]".to_string());
    CString::new(json_res).unwrap().into_raw()
}

#[no_mangle]
pub extern "C" fn free_string(s: *mut c_char) {
    if !s.is_null() {
        unsafe {
            let _ = CString::from_raw(s);
        }
    }
}

fn extract_attr(line: &str, attr: &str) -> Option<String> {
    let pattern = format!("{}=\"", attr);
    if let Some(start) = line.find(&pattern) {
        let rest = &line[start + pattern.len()..];
        if let Some(end) = rest.find('"') {
            return Some(rest[..end].to_string());
        }
    }
    None
}
