#!/bin/bash
set -e

# ===== ORBIT 3D BUILD SCRIPT =====
echo "🚀 === DÉMARRAGE BUILD ORBIT 3D ==="

# ✅ CHECK 1: cargo-ndk installé?
if ! command -v cargo-ndk &> /dev/null; then
    echo "❌ ERREUR: cargo-ndk non trouvé!"
    echo "Installation: cargo install cargo-ndk"
    exit 1
fi

# ✅ CHECK 2: Flutter SDK?
if ! command -v flutter &> /dev/null; then
    echo "❌ ERREUR: Flutter SDK non trouvé!"
    exit 1
fi

# ✅ CHECK 3: Android SDK?
if [ -z "$ANDROID_SDK_ROOT" ]; then
    echo "⚠️  ANDROID_SDK_ROOT non défini, tentative auto-détection..."
fi

echo ""
echo "=== 1️⃣  COMPILATION RUST FFI ==="
cd native
echo "📦 Building Rust avec cargo-ndk..."
cargo ndk -t arm64-v8a -t armeabi-v7a -o ../android/app/src/main/jniLibs build --release
if [ $? -eq 0 ]; then
    echo "✅ Rust compilé avec succès"
else
    echo "❌ Erreur Rust!"
    exit 1
fi
cd ..

echo ""
echo "=== 2️⃣  BUILD FLUTTER APK ==="
echo "🧹 Nettoyage Flutter..."
flutter clean

echo "📥 Récupération des dépendances..."
flutter pub get

echo "🔨 Compilation APK Release..."
flutter build apk --release --target-platform android-arm64

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ ======================================"
    echo "✅ BUILD RÉUSSI! 🎉"
    echo "✅ APK: build/app/outputs/flutter-apk/app-release.apk"
    echo "✅ ======================================"
else
    echo "❌ ERREUR lors du build APK!"
    exit 1
fi
